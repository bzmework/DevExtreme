﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DevExtreme.AspNet.Data.Types {

    class AnonTypeNewTweaks {
        public bool AllowEmpty = true;
        public bool AllowUnusedMembers = true;
    }

}
